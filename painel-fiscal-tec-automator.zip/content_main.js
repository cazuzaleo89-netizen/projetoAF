/**
 * Painel Fiscal — MAIN world script
 * Roda no contexto da página (não isolated), captura chamadas AJAX reais do TEC.
 * Comunica com content.js via CustomEvent (compartilham o mesmo DOM).
 */
(function () {
  'use strict';

  function _emit(detail) {
    window.dispatchEvent(new CustomEvent('_pf_tec_api', { detail }));
  }

  // ── Intercepta window.fetch real do TEC ─────────────────────────────────
  const _origFetch = window.fetch;
  window.fetch = function (input, init) {
    const url = typeof input === 'string' ? input : (input?.url || '');
    const prom = _origFetch.apply(this, arguments);

    if (url && url.includes('tecconcursos.com.br') &&
        /\/(api|v\d+)\/(questoes?|questao|search|buscar|filtrar)/i.test(url)) {
      _emit({ type: 'URL', base: url.split('?')[0], full: url });

      prom.then(async res => {
        try {
          const clone = res.clone();
          if ((clone.headers.get('content-type') || '').includes('json')) {
            const data = await clone.json();
            const items = Array.isArray(data) ? data
              : (data.data || data.questoes || data.items || data.results || []);
            if (Array.isArray(items) && items.length > 0) {
              _emit({
                type: 'DATA',
                base: url.split('?')[0],
                full: url,
                items: items.slice(0, 8).map(q => ({
                  id:       String(q.id || q.questao_id || q.questaoId || ''),
                  materia:  q.materia?.nome  || q.materia  || q.disciplina?.nome || '',
                  assunto:  q.assunto?.nome  || q.assunto  || '',
                  banca:    q.banca?.nome    || q.banca?.sigla || q.banca || '',
                  enunciado:(q.enunciado     || q.texto    || q.descricao || '').slice(0, 120),
                })).filter(q => q.id),
              });
            }
          }
        } catch (_) {}
      }).catch(() => {});
    }

    return prom;
  };

  // ── Intercepta XMLHttpRequest real do TEC ────────────────────────────────
  const _oxOpen = XMLHttpRequest.prototype.open;
  const _oxSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url) {
    this._pfUrl = url;
    return _oxOpen.apply(this, arguments);
  };

  XMLHttpRequest.prototype.send = function () {
    const url = this._pfUrl || '';
    if (url.includes('tecconcursos.com.br') &&
        /\/(api|v\d+)\/(questoes?|search)/i.test(url)) {
      _emit({ type: 'URL', base: url.split('?')[0], full: url });
      this.addEventListener('load', () => {
        try {
          const data = JSON.parse(this.responseText);
          const items = Array.isArray(data) ? data : (data.data || data.questoes || []);
          if (Array.isArray(items) && items.length > 0) {
            _emit({
              type: 'DATA', base: url.split('?')[0], full: url,
              items: items.slice(0, 8).map(q => ({
                id:      String(q.id || q.questao_id || ''),
                materia: q.materia?.nome || q.materia || '',
                assunto: q.assunto?.nome || q.assunto || '',
                banca:   q.banca?.nome  || q.banca   || '',
                enunciado: (q.enunciado || '').slice(0, 120),
              })).filter(q => q.id),
            });
          }
        } catch (_) {}
      });
    }
    return _oxSend.apply(this, arguments);
  };
})();
